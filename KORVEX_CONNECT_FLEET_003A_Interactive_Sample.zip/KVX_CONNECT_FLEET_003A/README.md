# KORVEX CONNECT — Fleet Pilot 003.A

## What this is
A self-contained **mobile-first interactive demo** of owner → driver invitation → driver assignment → expense submission → office verification → owner approval. This is a simulation only, not a production authentication or financial platform.

## Source-mapping basis
The supplied Cockpit V24 workbook was **read but not edited**. Existing worksheet designs consulted:
- `KVX EXPANDED MASTER`: Vehicle ID, Registration, Client Source (not owner), Assigned Driver ID.
- `DRIVERS`: driver source master.
- `TRIP ENTRY` and `TRIP OPERATIONS`: trip ID/operations.
- `KVX JOURNEY ENTRY`: Outward/Return plus diesel, RTO, toll, loading, weighbridge, batha, repairs.
- `COST ENTRY`: one row per cost/fuel expense.
- `KVX CASH EVENTS`: advances and cash events.
- `KVX JOURNEY SETTLE`: reconciliation.

The source contains unresolved `#REF!` fields; no source formulas or live financial totals are imported into the demo. Real owner authority, vehicle assignment, driver identity and financial figures are **not inferred** from workbook row associations.

## Demo flow (iPhone or desktop)
1. Open `index.html` in a full web browser, or upload this HTML as a separate page to a test-only host.
2. Owner tab → **Invite & assign** → Create demo invitation.
3. Driver tab → Accept demo invitation. Note no trip access yet.
4. Owner tab → Assign driver to the demo vehicle and trip.
5. Driver tab → Add expense. Optionally choose **Go offline** to queue an entry, then **Go online** → Sync.
6. Office tab → Verify an expense.
7. Owner tab → Approve it and inspect activity.
8. Reset demo clears the locally simulated scenario.

## Limits and security
- **No real login/invitation sending, access-control enforcement, backend, sync or server data.** Changing roles is a deliberate demo switch; it must not be mistaken for secure access.
- All data is **fictional**, except the requested display name Radha Krishnan. No real vehicle registration, driver name, phone number, customer trip, financial record, insurer record or API credential is embedded.
- Browser `localStorage` preserves fictional demo changes on that device. It is **not appropriate for customer data**.
- No API integration; no receipt image upload; no live alerts/GPS; no identity verification; no offline encryption; no actual fleet tenancy.
- GitHub Pages is public. Do **not** upload the source Cockpit workbook or real driver records there.

## Production requirements
Secure identity and invite token flow, tenant membership, driver-to-trip server permissions, device-risk handling, RBAC, private receipt storage, idempotent offline queue, verified audit trail, ledger reconciliation, backup/recovery and security testing are required before real-data use.

## Existing site preservation
Do **not** overwrite the existing `index.html` on `korvex-connect-demo` without approval. For a separate demo page, upload this file renamed `fleet-pilot.html` alongside it, then visit `/fleet-pilot.html` on the same GitHub Pages site.
